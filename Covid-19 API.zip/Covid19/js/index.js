$(document).ready(function () {
    $.get("https://api.covid19api.com/summary", function (data) {

        let array = data.Countries;

        let rateView = `<table class="table">`;

        rateView += `<thead class="thead-dark">
        <tr>
            <th scope="col">Countries</th>
            <th scope="col">Total Confirmed</th>
            <th scope="col">Total Deaths</th>
            <th scope="col">Total Recovered</th>
            <th scope="col">Date</th>
        </tr>
        </thead>`;


        rateView += array.map((country) => {

            return `
                <tr>
                    <td>${country.Country}</td>
                    <td>${country.TotalConfirmed}</td>
                    <td>${country.TotalDeaths}</td>
                    <td>${country.TotalRecovered}</td>
                    <td>${country.Date}</td>
                </tr>            
            `;

        }).join("");

        rateView += `</table>`

        $("#result").append(rateView);
    });
});

function home() {
    $("#result").empty();
    $(document).ready(function () {
        $.get("https://api.covid19api.com/summary", function (data) {

            let array = data.Countries;

            let rateView = `<table class="table">`;

            rateView += `<thead class="thead-dark">
            <tr>
                <th scope="col">Countries</th>
                <th scope="col">Total Confirmed</th>
                <th scope="col">Total Deaths</th>
                <th scope="col">Total Recovered</th>
                <th scope="col">Date</th>
            </tr>
            </thead>`;


            rateView += array.map((country) => {

                return `
                    <tr>
                        <td>${country.Country}</td>
                        <td>${country.TotalConfirmed}</td>
                        <td>${country.TotalDeaths}</td>
                        <td>${country.TotalRecovered}</td>
                        <td>${country.Date}</td>
                    </tr>            
                `;

            }).join("");

            rateView += `</table>`

            $("#result").append(rateView);
        });
    });
};



function builtProductView(datas) {
    let rateView = `<table class="table">`;
    rateView += `
    <thead class="thead-dark">
        <tr>
            <th scope="col">Countries</th>
            <th scope="col">Total Confirmed</th>
            <th scope="col">Total Deaths</th>
            <th scope="col">Total Recovered</th>
            <th scope="col">Date</th>
        </tr>
    </thead>`;

    rateView += datas.map((elem) => {
        return `
    <tr>
        <td>${elem.Country}</td>
        <td>${elem.TotalConfirmed}</td>
        <td>${elem.TotalDeaths}</td>
        <td>${elem.TotalRecovered}</td>
        <td>${elem.Date}</td>
    </tr>            
`;
    }).join("");
    rateView += "</table>"
    $("#result").append(rateView);
}


$(".bar").click(function (e) {
    $("#result").empty();
    let thisHtml = $(this).html();
    $.get("https://api.covid19api.com/summary", (data) => {
        let foo = data.Countries.filter((country) => {
            if (country.Country == thisHtml) {
                return true;
            } else {
                return false;
            }
        });
        builtProductView(foo);
    });
});


function filterFunction() {


}